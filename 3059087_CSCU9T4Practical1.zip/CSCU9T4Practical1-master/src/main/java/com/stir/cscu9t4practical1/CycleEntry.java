//[6]Implement the additional classes needed to represent the different types of training sessions. (Cycle)
package com.stir.cscu9t4practical1;

public class CycleEntry extends Entry{
    private String terrain;
    private String tempo;
            
    public CycleEntry (String n, int d, int m, int y, int h, int min, int s, float dist, String ter, String tem) {
    super(n, d, m, y, h, min, s, dist);
    terrain = ter;
    tempo = tem;
  } //constructor

  public String getTerrain () {
      return terrain;
  } //getTerrain
  
  public String getTempo () {
      return tempo;
  } //getTempo

  public String getEntry () {
   String result = getName()+" cycled " + getDistance() + " km on "
             +getTerrain()+" with "+getTempo()+" tempo in "
             +getHour()+":"+getMin()+":"+ getSec() + " on "
             +getDay()+"/"+getMonth()+"/"+getYear()+"\n";
   return result;
  } //getEntry
  
} // CycleEntry
