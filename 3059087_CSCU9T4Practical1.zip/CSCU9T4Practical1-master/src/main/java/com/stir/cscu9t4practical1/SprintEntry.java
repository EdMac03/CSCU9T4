//[6]Implement the additional classes needed to represent the different types of training sessions. (Sprint)
package com.stir.cscu9t4practical1;

public class SprintEntry extends Entry{
    private int repeat;
    private int recover;
    
  public SprintEntry (String n, int d, int m, int y, int h, int min, int s, float dist, int rep, int rec) {
    super(n, d, m, y, h, min, s, dist);
    repeat = rep;
    recover = rec;
  } //constructor
  
  public int getRepeat () {
      return repeat;
  } //getRepeat
  
  public int getRecover () {
      return recover;
  } //getRecover
  
  public String getEntry () {
   String result = getName()+" ran for " + getRepeat() + " * " + getDistance()
             + " km (with " + getRecover() + " minutes recovery between), in  "
             +getHour()+":"+getMin()+":"+ getSec() + " on "
             +getDay()+"/"+getMonth()+"/"+getYear()+"\n";
   return result;
  } //getEntry  
}
