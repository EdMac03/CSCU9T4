//[6]Implement the additional classes needed to represent the different types of training sessions. (Swim)
package com.stir.cscu9t4practical1;

public class SwimEntry extends Entry{
  private String location;
  
  public SwimEntry (String n, int d, int m, int y, int h, int min, int s, float dist, String loc) {
    super(n, d, m, y, h, min, s, dist);
    location = loc;
  } //constructor

  public String getLocation () {
      return location;
  } //getLocation

  public String getEntry () {
   String result = getName()+" swam " + getDistance() + " km in the " + getLocation() +", in "
             +getHour()+":"+getMin()+":"+ getSec() + " on "
             +getDay()+"/"+getMonth()+"/"+getYear()+"\n";
   return result;
  } //getEntry
  
} // SwimEntry
